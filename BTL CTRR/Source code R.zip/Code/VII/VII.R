library(readr)
library(dplyr)
library(ggplot2)
library(RcppRoll)
raw_data <- read_csv("owid-covid-data.csv")
main_data <- cbind(raw_data,as.Date(raw_data$date,"%m/%d/%Y"))
colnames(main_data) <- c("iso_code","continent","location","date","new_cases","new_deaths","date_key")

# ************************************ Nhom cau vii *********************************************
# cau 1:
vii_1_2020 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2020" & !is.na(new_cases) & (month == "01" | month == "04" | month == "05" | month == "08"))%>%
  group_by(date) %>%
  summarise(total_new_cases = sum(new_cases)) %>%
  ggplot(aes(x = date, y = total_new_cases)) +
  geom_histogram(stat='identity') + 
  labs(title = "2020", x = "months", y = "new cases")

vii_1_2021 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2021" & !is.na(new_cases) & (month == "01" | month == "04" | month == "05" | month == "08"))%>%
  group_by(date) %>%
  summarise(total_new_cases = sum(new_cases)) %>%
  ggplot(aes(x = date, y = total_new_cases)) +
  geom_histogram(stat='identity') + 
  labs(title = "2021", x = "months", y = "new cases")

vii_1_2022 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2022" & !is.na(new_cases) & (month == "01" | month == "04" | month == "05" | month == "08"))%>%
  group_by(date) %>%
  summarise(total_new_cases = sum(new_cases)) %>%
  ggplot(aes(x = date, y = total_new_cases)) +
  geom_histogram(stat='identity') + 
  labs(title = "2022", x = "months", y = "new cases")

# cau 2
vii_2_2020 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2020" & !is.na(new_deaths) & (month == "01" | month == "04" | month == "05" | month == "08"))%>%
  group_by(date) %>%
  summarise(total_new_deaths = sum(new_deaths)) %>%
  ggplot(aes(x = date, y = total_new_deaths)) +
  geom_histogram(stat='identity') + 
  labs(title = "2020", x = "months", y = "new deaths")

vii_2_2021 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2021" & !is.na(new_deaths) & (month == "01" | month == "04" | month == "05" | month == "08"))%>%
  group_by(date) %>%
  summarise(total_new_deaths = sum(new_deaths)) %>%
  ggplot(aes(x = date, y = total_new_deaths)) +
  geom_histogram(stat='identity') + 
  labs(title = "2021", x = "months", y = "new deaths")

vii_2_2022 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2022" & !is.na(new_deaths) & (month == "01" | month == "04" | month == "05" | month == "08"))%>%
  group_by(date) %>%
  summarise(total_new_deaths = sum(new_deaths)) %>%
  ggplot(aes(x = date, y = total_new_deaths)) +
  geom_histogram(stat='identity') + 
  labs(title = "2022", x = "months", y = "new deaths")

# cau 3
vii_3_2020 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2020" & !is.na(new_cases) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_cases = sum(new_cases)) %>%
  ggplot(aes(x = date, y = total_new_cases)) +
  geom_histogram(stat='identity') + 
  labs(title = "2020", x = "months", y = "new cases")

vii_3_2021 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2021" & !is.na(new_cases) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_cases = sum(new_cases)) %>%
  ggplot(aes(x = date, y = total_new_cases)) +
  geom_histogram(stat='identity') + 
  labs(title = "2021", x = "months", y = "new cases")

vii_3_2022 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2022" & !is.na(new_cases) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_cases = sum(new_cases)) %>%
  ggplot(aes(x = date, y = total_new_cases)) +
  geom_histogram(stat='identity') + 
  labs(title = "2022", x = "months", y = "new cases")

# cau 4
vii_4_2020 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2020" & !is.na(new_deaths) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_deaths = sum(new_deaths)) %>%
  ggplot(aes(x = date, y = total_new_deaths)) +
  geom_histogram(stat='identity') + 
  labs(title = "2020", x = "months", y = "new deaths")

vii_4_2021 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2021" & !is.na(new_deaths) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_deaths = sum(new_deaths)) %>%
  ggplot(aes(x = date, y = total_new_deaths)) +
  geom_histogram(stat='identity') + 
  labs(title = "2021", x = "months", y = "new deaths")

vii_4_2022 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2022" & !is.na(new_deaths) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_deaths = sum(new_deaths)) %>%
  ggplot(aes(x = date, y = total_new_deaths)) +
  geom_histogram(stat='identity') + 
  labs(title = "2022", x = "months", y = "new deaths")

# cau 5
vii_5_2020 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2020" & !is.na(new_cases) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_cases = sum(new_cases))

vii_5_2020$cumulative_percentage = 100*cumsum(vii_5_2020$total_new_cases)/sum(vii_5_2020$total_new_cases)

ggplot(vii_5_2020, aes(x = date, y = cumulative_percentage)) +
  geom_histogram(stat='identity') + 
  labs(title = "2020", x = "months", y = "new cases")

vii_5_2021 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2021" & !is.na(new_cases) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_cases = sum(new_cases))

vii_5_2021$cumulative_percentage = 100*cumsum(vii_5_2021$total_new_cases)/sum(vii_5_2021$total_new_cases)

ggplot(vii_5_2021, aes(x = date, y = cumulative_percentage)) +
  geom_histogram(stat='identity') + 
  labs(title = "2021", x = "months", y = "new cases")

vii_5_2022 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2022" & !is.na(new_cases) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_cases = sum(new_cases))

vii_5_2022$cumulative_percentage = 100*cumsum(vii_5_2022$total_new_cases)/sum(vii_5_2022$total_new_cases)

ggplot(vii_5_2022, aes(x = date, y = cumulative_percentage)) +
  geom_histogram(stat='identity') + 
  labs(title = "2022", x = "months", y = "new cases")

# cau 6
vii_6_2020 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2020" & !is.na(new_deaths) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_deaths = sum(new_deaths))

vii_6_2020$cumulative_percentage = 100*cumsum(vii_6_2020$total_new_deaths)/sum(vii_6_2020$total_new_deaths)

ggplot(vii_6_2020, aes(x = date, y = cumulative_percentage)) +
  geom_histogram(stat='identity') + 
  labs(title = "2020", x = "months", y = "new deaths")

vii_6_2021 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2021" & !is.na(new_deaths) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_deaths = sum(new_deaths))

vii_6_2021$cumulative_percentage = 100*cumsum(vii_6_2021$total_new_deaths)/sum(vii_6_2021$total_new_deaths)

ggplot(vii_6_2021, aes(x = date, y = cumulative_percentage)) +
  geom_histogram(stat='identity') + 
  labs(title = "2021", x = "months", y = "new deaths")

vii_6_2022 <- main_data%>%
  cbind(year=format(main_data$date_key, "%Y"), month=format(main_data$date_key, "%m"))%>%
  filter(year == "2022" & !is.na(new_deaths) & (month == "11" | month == "12"))%>%
  group_by(date) %>%
  summarise(total_new_deaths = sum(new_deaths))

vii_6_2022$cumulative_percentage = 100*cumsum(vii_6_2022$total_new_deaths)/sum(vii_6_2022$total_new_deaths)

ggplot(vii_6_2022, aes(x = date, y = cumulative_percentage)) +
  geom_histogram(stat='identity') + 
  labs(title = "2022", x = "months", y = "new deaths")