install.packages("readr")
install.packages("xlsx")
install.packages("dplyr")
install.packages("stringr")
library("readr")
library("xlsx")
library("dplyr")
library("stringr")
raw_data <- read_csv ("C:\\ctrr\\owid-covid-data.csv")
filter_data = raw_data %>% filter(location == "Kenya" | location == "Lesotho" | location == "Morocco")
#phan i
#1
i1 = filter_data$date %>% stringr::str_sub(-4) %>% data.frame() %>% distinct() 

#2
i2 = raw_data %>% select(iso_code, Country = location) %>% distinct() %>% head(10)

#3
i3 <- raw_data %>% select(continent) %>% distinct()
i3$so_chau_luc <- c("Ch�u �" , "N/A" , "Ch�u �u" , "Ch�u Phi" , "Ch�u B???c M??" , "Ch�u Nam M??" , "Ch�u �???i D��ng")

#4
i4 = raw_data %>% count(continent)
i4 = i4 %>% add_row(continent = "Tong", n = sum(i4$n))
i4 = rename(i4,"Observations" = "n")

#5
i5 = raw_data %>% count(iso_code) %>% tail(10) 
i5 = i5 %>% add_row(iso_code = "Tong", n = sum(i5$n))
i5 = rename(i5, "Observation" = "n")

#6
i6 = i4 %>% slice_min(Observations)

#7
i7 = subset(i4, continent!="Tong") %>% slice_max(Observations)

#8
i8 = raw_data %>% count(location) %>% slice_min(n)

#9
i9 = raw_data %>% count(location) %>% slice_max(n)

#10
i10 = raw_data %>% count(date) %>% slice_min(n)

#11
i11 = raw_data %>% count(date) %>% slice_max(n)

main_data <- cbind(raw_data,as.Date(raw_data$date,"%m/%d/%Y"))
colnames(main_data) <- c("iso_code","continent","location","date","new_cases","new_deaths","date_key")
main_data <- main_data[order(main_data$iso_code,main_data$date_key,decreasing = FALSE),] 

#12
i12 = raw_data %>% count(continent, date)
i12 = filter(i12, continent!="NA")

#13
i13 = i12 %>% slice_max(n)


#14
i14 = i12 %>% slice_min(n)


#15
i15 = raw_data %>% filter(date=="1/1/2021", continent=="Africa")
i15 = i15 %>% count(continent, date)
