# install.packages('readr')
# install.packages('dplyr')
# install.packages('ggplot2')
library(readr)
library(dplyr)
data <- read_csv(file = 'C:/Users/Binh/Documents/TRR/owid-covid-data.csv')
data <- filter(
  data, location == "Kenya"
  | location == "Lesotho"
  | location == "Morocco"
)

# Phan 2
# 1 Vẽ biểu đồ tần số tích lũy quốc gia cho các châu lục
all_data <- read_csv(file = 'C:/Users/Binh/Documents/TRR/owid-covid-data.csv')
all_data <- filter(all_data, !is.na(continent) | !is.na(location))
dtp2c1 <- all_data %>% group_by(continent, location) %>% summarise(count_value = n())
dtp2c1$continent[is.na(dtp2c1$continent)] <- "No location"
dtp2c1 <- data.frame(
  location=c(dtp2c1$location),
  continent=c(dtp2c1$continent),
  count_value=c(dtp2c1$count_value)
)
ggplot(dtp2c1, aes(x = continent, y = count_value, fill = continent)) + geom_col()

# 2 Vẽ biểu đồ tần số tương đối quốc gia cho các châu lục
# https://www.mathway.com/vi/popular-problems/Finite%20Math/621943#:~:text=T%E1%BA%A7n%20s%E1%BB%91%20t%C6%B0%C6%A1ng%20%C4%91%E1%BB%91i%20c%E1%BB%A7a,t%E1%BA%A5t%20c%E1%BA%A3%20c%C3%A1c%20t%E1%BA%A7n%20s%E1%BB%91.&text=n%20l%C3%A0%20t%E1%BB%95ng%20c%E1%BB%A7a%20t%E1%BA%A5t%20c%E1%BA%A3%20c%C3%A1c%20t%E1%BA%A7n%20s%E1%BB%91.,-Trong%20tr%C6%B0%E1%BB%9Dng%20h%E1%BB%A3p
all_data <- read_csv(file = 'C:/Users/Binh/Documents/TRR/owid-covid-data.csv')
all_data <- filter(all_data, !is.na(continent) | !is.na(location))
all_data <- filter(
  all_data, location == "Kenya"
  | location == "Lesotho"
  | location == "Morocco"
)
dtp2c2 <- all_data %>% group_by(continent, location) %>% summarise(count_value = n())
dtp2c2$continent[is.na(dtp2c2$continent)] <- "No location"
dtp2c2$count_value <- dtp2c2$count_value/sum_tmp
dtp2c2 <- data.frame(
  location=c(dtp2c2$location),
  continent=c(dtp2c2$continent),
  count_value=c(dtp2c2$count_value)
)
ggplot(dtp2c2, aes(x = location, y = count_value, fill = location)) + geom_col()

# 3 Vẽ biểu đồ thể hiện nhiễm bệnh đã báo cáo của các quốc gia mà thuộc về nhóm trong 7 ngày cuối của năm cuối cùng
all_data <- read_csv(file = 'C:/Users/Binh/Documents/TRR/owid-covid-data.csv')
all_data <- filter(
  all_data, location == "Kenya"
  | location == "Lesotho"
  | location == "Morocco"
)
all_data <- filter(all_data, !is.na(continent) | !is.na(location))
all_data <- all_data[order(all_data$date, decreasing = TRUE),]

# filter data last 7 day
lastDate <- as.Date(all_data$date[1], "%m/%d/%y")
last7Date <- lastDate - 7
all_data$date <- as.Date(all_data$date, "%m/%d/%y")
all_data <- filter(all_data, date > last7Date)

#
data_calculated <- all_data %>% group_by(location) %>% summarise(new_case_num = sum(new_cases))
data_calculated <- filter(data_calculated, !is.na(new_case_num))
data_chart <- data.frame(
  location=c(data_calculated$location),
  new_case_num=c(data_calculated$new_case_num)
)
ggplot(data_chart, aes(x = location, y = new_case_num, fill = location)) + geom_col()


# 4 Vẽ biểu đồ thể hiện tử vong đã báo cáo của các quốc gia mà thuộc về nhóm trong 7 ngày cuối của năm cuối cùng
all_data <- read_csv(file = 'C:/Users/Binh/Documents/TRR/owid-covid-data.csv')
all_data <- filter(
  all_data, location == "Kenya"
  | location == "Lesotho"
  | location == "Morocco"
)
all_data <- filter(all_data, !is.na(continent) | !is.na(location))
all_data <- all_data[order(all_data$date, decreasing = TRUE),]

# filter data last 7 day
lastDate <- as.Date(all_data$date[1], "%m/%d/%y")
last7Date <- lastDate - 7
all_data$date <- as.Date(all_data$date, "%m/%d/%y")
all_data <- filter(all_data, date > last7Date)

#
data_calculated <- all_data %>% group_by(location) %>% summarise(deadth_num = sum(new_deaths))
data_calculated <- filter(data_calculated, !is.na(deadth_num))
data_chart <- data.frame(
  location=c(data_calculated$location),
  deadth_num=c(data_calculated$deadth_num)
)
ggplot(data_chart, aes(x = location, y = deadth_num, fill = location)) + geom_col()

# 5 Vẽ biểu đồ phổ đất nước xuất hiện outliers cho nhiễm bệnh
all_data <- read_csv(file = 'C:/Users/Binh/Documents/TRR/owid-covid-data.csv')
all_data <- filter(
  all_data, location == "Kenya"
  | location == "Lesotho"
  | location == "Morocco"
)
all_data <- filter(all_data, !is.na(new_cases))
q_nd <- quantile(unlist(all_data$new_cases), prob=c(0,.25,.5,.75, 1))
q1 <- q_nd['25%']
q2 <- q_nd['50%']
q3 <- q_nd['75%']
qtr <- q3 - q1
all_data <- filter(all_data, new_cases < q2 - 1.5*qtr | new_cases > q2 - 1.5*qtr)
data_chart5 <- all_data %>% group_by(location) %>% summarise(count_outliers = n())
ggplot(data_chart5, aes(x = location, y = count_outliers, fill = location)) + geom_col()

# 6 Vẽ biểu đồ phổ đất nước xuất hiện outliers cho tử vong
all_data <- read_csv(file = 'C:/Users/Binh/Documents/TRR/owid-covid-data.csv')
all_data <- filter(
  all_data, location == "Kenya"
  | location == "Lesotho"
  | location == "Morocco"
)
all_data <- filter(all_data, !is.na(new_deaths))
q_nd <- quantile(unlist(all_data$new_deaths), prob=c(0,.25,.5,.75, 1))
q1 <- q_nd['25%']
q2 <- q_nd['50%']
q3 <- q_nd['75%']
qtr <- q3 - q1
all_data <- filter(all_data, new_deaths < q2 - 1.5*qtr | new_deaths > q2 - 1.5*qtr)
data_chart6 <- all_data %>% group_by(location) %>% summarise(count_outliers = n())
ggplot(data_chart6, aes(x = location, y = count_outliers, fill = location)) + geom_col()
