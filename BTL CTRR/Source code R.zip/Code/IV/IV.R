# install.packages('readr')
# install.packages('dplyr')
# install.packages('ggplot2')
library(readr)
library(dplyr)
data <- read_csv(file = 'C:/Users/Binh/Documents/TRR/owid-covid-data.csv')
data <- filter(
  data, location == "Kenya"
  | location == "Lesotho"
  | location == "Morocco"
)

# 1) Tính giá trị nhỏ nhất, lớn nhất
# new cases
e1 <- filter(data, !is.na(new_cases))
e1 <- e1[order(e1$new_cases),]
max_new_case <- tail(e1, n =1)
min_new_case <- head(e1, n =1)
print(max_new_case)
print(min_new_case)

# new deaths
e2 <- filter(data, !is.na(new_deaths))
e2 <- e2[order(e2$new_deaths),]
max_new_deaths <- tail(e2, n =1)
min_new_deaths <- head(e2, n =1)
print(max_new_deaths)
print(min_new_deaths)

# 2) Tính tứ phân vị thứ nhất(Q1), thứ hai(Q2), thứ ba(Q3)

# new cases
data_c2 <- filter(data, !is.na(new_cases))
data_c2 <- transform(data_c2, new_cases = as.numeric(new_cases))
data_c2 <- data_c2[order(data_c2$new_cases),]
arr_new_cases <- as.vector(data_c2['new_cases'])

# new deaths
data_c2 <- filter(data, !is.na(new_deaths))
data_c2 <- transform(data_c2, new_deaths = as.numeric(new_deaths))
data_c2 <- data_c2[order(data_c2$new_deaths),]
arr_new_deaths <- as.vector(data_c2['new_deaths'])

q_arr_nc <- quantile(unlist(arr_new_cases), prob=c(0,.25,.5,.75, 1)) 
q_arr_nd <- quantile(unlist(arr_new_deaths), prob=c(0,.25,.5,.75, 1)) 

# New death
print(q_arr_nc)

# New case
print(q_arr_nd)

# 3) Tính giá trị trung bình (Avg)
avgnc <- mean(unlist(arr_new_cases))
avgnd <- mean(unlist(arr_new_deaths))
print(avgnc)
print(avgnd)

# 4) Tính giá trị độ lệch chuẩn (Std)
variancenc <- var(unlist(arr_new_cases))
variancend <- var(unlist(arr_new_deaths))
print(variancenc)
print(variancend)

# 5) Đếm xem có bao nhiêu outliers, một quan sát mà giá trị của nó nằm trong khoảng sau:
# IQR = Q3 − Q1
# outliers < Q1 −1.5 ∗IQR hoặc outliers > Q3 + 1.5 ∗IQR

# new case
q1_nc <- as.numeric(q_arr_nc['25%'])
q3_nc <- as.numeric(q_arr_nc['75%'])
qtr_nc <- q3_nc - q1_nc
data_for_e5nc <- filter(data, !is.na(new_cases))
data_for_e5nc <- transform(data_for_e5nc, new_cases = as.numeric(new_cases))
e5nc <- filter(data_for_e5nc, (new_cases < q1_nc - 1.5*qtr_nc) | (new_cases > q3_nc + 1.5*qtr_nc))
print(nrow(e5nc))

# new death
q1_nd <- as.numeric(q_arr_nd['25%'])
q3_nd <- as.numeric(q_arr_nd['75%'])
qtr_nd <- q3_nd - q1_nd
data_for_e5nd <- filter(data, !is.na(new_deaths))
data_for_e5nd <- transform(data_for_e5nc, new_deaths = as.numeric(new_deaths))
e5nd <- filter(data_for_e5nd, new_deaths < q1_nc - 1.5*qtr_nd | new_deaths > q3_nc - 1.5*qtr_nd)
print(nrow(e5nd))

# 6) Lập bảng mô tả số liệu thống kê cho từng đất nước thuộc về nhóm

# new cases
rs_nc <- data.frame(matrix(ncol = 9, nrow = 0))
colnames(rs_nc) <- c('Countries', 'Min', 'Q1', 'Q2', 'Q3', 'Max', 'Avg', 'Std', 'Outlier')
calc_row_nc <- function(country) {
  calc_data <- filter(data, location == country)
  calc_data <- filter(calc_data, !is.na(new_cases))
  calc_data <- calc_data[order(calc_data$new_cases),]
  cacl_q_nc <- quantile(unlist(calc_data$new_cases), prob=c(0,.25,.5,.75, 1))
  q1 <- cacl_q_nc['25%']
  q2 <- cacl_q_nc['50%']
  q3 <- cacl_q_nc['75%']
  qtr <- q3 - q1
  minVal <- cacl_q_nc['0%']
  maxVal <- cacl_q_nc['100%']
  avgVal <- mean(calc_data$new_cases)
  stdVal <- var(calc_data$new_cases)
  outlier <- nrow(filter(calc_data, new_cases < q2 - 1.5*qtr | new_cases > q2 - 1.5*qtr))
  print(c(
    country,
    minVal,
    q1,
    q2,
    q3,
    maxVal,
    avgVal,
    stdVal,
    outlier
  ))
  return(c(
    country,
    minVal,
    q1,
    q2,
    q3,
    maxVal,
    avgVal,
    stdVal,
    outlier
  ))
}
rs_nc[nrow(rs_nc) + 1,] = calc_row_nc('Kenya')
rs_nc[nrow(rs_nc) + 1,] = calc_row_nc('Lesotho')
rs_nc[nrow(rs_nc) + 1,] = calc_row_nc('Morocco')
print(rs_nc)


# new deaths
rs_nd <- data.frame(matrix(ncol = 9, nrow = 0))
colnames(rs_nd) <- c('Countries', 'Min', 'Q1', 'Q2', 'Q3', 'Max', 'Avg', 'Std', 'Outlier')
calc_row_nd <- function(country) {
  calc_data <- filter(data, location == country)
  calc_data <- filter(calc_data, !is.na(new_deaths))
  calc_data <- calc_data[order(calc_data$new_deaths),]
  cacl_q_nd <- quantile(unlist(calc_data$new_deaths), prob=c(0,.25,.5,.75, 1))
  q1 <- cacl_q_nd['25%']
  q2 <- cacl_q_nd['50%']
  q3 <- cacl_q_nd['75%']
  qtr <- q3 - q1
  stem(cacl_q_nd)
  minVal <- cacl_q_nd['0%']
  maxVal <- cacl_q_nd['100%']
  avgVal <- mean(calc_data$new_deaths)
  stdVal <- var(calc_data$new_deaths)
  outlier <- nrow(filter(calc_data, new_deaths < q2 - 1.5*qtr | new_deaths > q2 - 1.5*qtr))
  
  return(c(
    country,
    minVal,
    q1,
    q2,
    q3,
    maxVal,
    avgVal,
    stdVal,
    outlier
  ))
}
rs_nd[nrow(rs_nd) + 1,] = calc_row_nd('Kenya')
rs_nd[nrow(rs_nd) + 1,] = calc_row_nd('Lesotho')
rs_nd[nrow(rs_nd) + 1,] = calc_row_nd('Morocco')
print(rs_nd)

# 6) Lập bảng mô tả số liệu thống kê cho từng đất nước thuộc về nhóm
library(ggplot2)
# Basic box plot
rs_nc$Min <- as.numeric(rs_nc$Min)
rs_nc$Q1 <- as.numeric(rs_nc$Q1)
rs_nc$Q2 <- as.numeric(rs_nc$Q2)
rs_nc$Q3 <- as.numeric(rs_nc$Q3)
rs_nc$Max <- as.numeric(rs_nc$Max)
ggplot(
  rs_nc,
  aes(x=Countries, ymin=Min, lower=Q1, middle=Q2, upper=Q3, ymax=Max, colour=Countries)
) + geom_boxplot(stat="identity")