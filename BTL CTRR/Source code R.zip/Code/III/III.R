install.packages("readr")
install.packages("xlsx")
install.packages("dplyr")
install.packages("stringr")
library("readr")
library("xlsx")
library("dplyr")
library("stringr")
raw_data <- read_csv ("C:\\ctrr\\owid-covid-data.csv")
filter_data = raw_data %>% filter(location == "Kenya" | location == "Lesotho" | location == "Morocco")

#phan iii

#1
iii1_1 = filter_data %>% filter(new_cases==0 | is.na(new_cases)) %>% count(location) %>% rename(new_cases = "n")
iii1_2 = filter_data %>% filter(new_deaths==0 | is.na(new_deaths)) %>% count(location) %>% rename(new_deaths = "n")


#2
iii2_1 = filter_data %>% filter(new_cases!=0) %>% group_by(location) %>% slice_min(new_cases) %>% count(new_cases)
iii2_2 = filter_data %>% filter(new_deaths!=0) %>% group_by(location) %>% slice_min(new_deaths) %>% count(new_deaths)


#3
iii3_1 = filter_data %>% filter(new_cases!=0) %>% group_by(location) %>% slice_max(new_cases) %>% count(new_cases) %>% rename(max_new_cases = "n")
iii3_2 = filter_data %>% filter(new_deaths!=0) %>% group_by(location) %>% slice_max(new_deaths) %>% count(new_deaths) %>% rename(max_new_deaths = "n")


#4
iii4_1 = full_join(iii1_1,iii1_2)
iii4_2 = full_join(iii3_1,iii3_2)

#5