main_data <- cbind(filter_data,as.Date(filter_data$date,"%m/%d/%Y"))
colnames(main_data) <- c("iso_code","continent","location","date","new_cases","new_deaths","date_key")

#Them cot thang va dinh dang number
main_data["months"] = as.numeric(format(main_data$date_key, format = "%m"))
main_data["years"] = as.numeric(format(main_data$date_key, format ="%Y" ))
#Loc du lieu theo dieu kien: quoc gia, thang thuc hien
ThangTH <-c(1,8,4,5)
Years <- c(unique(main_data$years))
QGia <- c(unique(main_data$location))
CasePerMonth <- main_data %>% filter(months==ThangTH[1] & years ==Years[2] & location %in% QGia )

#Ve bieu do tich luy
ggplot(data = CasePerMonth, aes(x=CasePerMonth$new_deaths)) + geom_density(fill= "Orange") +
  scale_y_continuous(name = "Tich luy") +
  scale_x_continuous(breaks = round(seq(min(CasePerMonth$new_deaths), max(CasePerMonth$new_deaths), by = 10),10), name = "Ca tu vong") +
  theme(axis.text.x = element_text(angle = 0, hjust = 1, color = "red")) +
  theme(axis.title.y = element_text(color = "blue"))+
  ggtitle("Bieu do tich luy thang 01/2021")
