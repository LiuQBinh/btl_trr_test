install.packages("readr")
install.packages("xlsx")
install.packages("dplyr")
install.packages("stringr")
install.packages("ggplot2")
install.packages("scales")
install.packages("tidyverse")
install.packages("magrittr")
install.packages("lubridate")

library("readr")
library("xlsx")
library("dplyr")
library("stringr")
library("ggplot2")
library("scales")
library("tidyverse")
library("magrittr")
library("lubridate")


raw_data <- read_csv ("D:\\ctrr\\owid-covid-data.csv")

list_location <- c("Kenya", "Lesotho", "Morocco")
filter_data <- raw_data %>% filter(location == list_location)

#main data
main_data <- cbind(filter_data,as.Date(filter_data$date,"%m/%d/%Y"))
colnames(main_data) <- c("iso_code","continent","location","date","new_cases","new_deaths","date_key")

#Them cot thang va dinh dang number
main_data["months"] = as.numeric(format(main_data$date_key, format = "%m"))
main_data["years"] = as.numeric(format(main_data$date_key, format ="%Y" ))
#Loc du lieu theo dieu kien: quoc gia, thang thuc hien
ThangTH <-c(1,8,4,5)
Years <- c(unique(main_data$years))

CasePerMonth <- main_data %>% filter(months==ThangTH[4] & years ==Years[2] )
CasePerMonth$date_key<-as.POSIXct(CasePerMonth$date_key, format="%Y-%m-%d")

#Bieu do ca tu vong 
ggplot(data = CasePerMonth, aes(x=date_key, y=new_deaths, group = location, colour = location)) +
  geom_line() +
  scale_x_datetime("Thoi gian", date_breaks = "3 days", date_labels = "%m-%d-%Y") +
  scale_y_continuous("Ca tu vong")+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, color = "black"))

