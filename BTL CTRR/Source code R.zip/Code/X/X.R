library("readr")
library("xlsx")
library("dplyr")
library("stringr")
library("ggplot2")
library("RcppRoll")

raw_data <- read_csv ("D:\\ctrr\\owid-covid-data.csv")

main_data <- cbind(raw_data,as.Date(raw_data$date,"%m/%d/%Y"))
colnames(main_data) <- c("iso_code","continent","location","date","new_cases","new_deaths","date_key")
main_data <- main_data[order(main_data$iso_code,main_data$date_key,decreasing = FALSE),]

filter_data <- main_data %>% filter(location == c("Kenya", "Lesotho", "Morocco"))

ken <- main_data%>%
  filter(location == 'Kenya')
lso <- main_data%>%
  filter(location == 'Lesotho')
mar <- main_data%>%
  filter(location == 'Morocco')
# ************************************ Nhom cau x *********************************************

-- x
x <- main_data %>% filter(!is.na(continent))

x1 <- x %>% filter(x$date_key >= max(x$date_key)-7) %>% group_by(location) %>% summarise(Total_new_cases = sum(new_cases,na.rm = TRUE), Avg_new_cases = mean(new_cases,na.rm = TRUE))
x1 <- x1[order(x1$Total_new_cases,na.last = TRUE, decreasing = TRUE),]
head(x1, 10)

k_new_cases <- 3000000
x2 <- x %>% 
  group_by(date_key) %>% 
  summarise (Total_new_cases = sum(new_cases, na.rm = TRUE)) %>% 
  mutate(Total_new_cases_last_7_days = roll_sum(Total_new_cases,7,fill = 0, align = "right")) %>% 
  mutate(check_above_k = Total_new_cases_last_7_days > k_new_cases) %>%
  mutate(last_check = lag(check_above_k, 1,order_by = date_key)) %>% 
  mutate(next_check = lead(check_above_k, 1, order_by = date_key)) %>%
  mutate(is_start_point = !last_check & check_above_k) %>% 
  mutate(is_end_point = !next_check & check_above_k) %>%
  mutate(count_start = cumsum(ifelse(is_start_point, 1, 0))) %>%
  mutate(outbreak_no = ifelse(check_above_k, count_start, 0))

ggplot () + 
  geom_line(data = x2 , aes(x = date_key, y = Total_new_cases_last_7_days), color = "blue") +
  geom_line(data = x2 , aes(x = date_key, y = k_new_cases), color = "red") +
  labs(title = "New cases outbreak at 3000000 (last 7 days)", x = "Date", y = "New cases last 7 days")

x2_outbreak_list <-
  x2 %>% filter(outbreak_no != 0) %>%
  group_by(outbreak_no) %>%
  summarise (Start_date = min(date_key), End_date = max(date_key))

k_new_deaths <- 64000
x3 <- x %>% 
  group_by(date_key) %>% 
  summarise (Total_new_deaths = sum(new_deaths, na.rm = TRUE)) %>% 
  mutate(Total_new_deaths_last_7_days = roll_sum(Total_new_deaths,7,fill = 0, align = "right")) %>% 
  mutate(check_above_k = Total_new_deaths_last_7_days > k_new_deaths) %>%
  mutate(last_check = lag(check_above_k, 1,order_by = date_key)) %>% 
  mutate(next_check = lead(check_above_k, 1, order_by = date_key)) %>%
  mutate(is_start_point = !last_check & check_above_k) %>% 
  mutate(is_end_point = !next_check & check_above_k) %>%
  mutate(count_start = cumsum(ifelse(is_start_point, 1, 0))) %>%
  mutate(outbreak_no = ifelse(check_above_k, count_start, 0))

ggplot () + 
  geom_line(data = x3 , aes(x = date_key, y = Total_new_deaths_last_7_days), color = "blue") +
  geom_line(data = x3 , aes(x = date_key, y = k_new_deaths), color = "red") +
  labs(title = "New deaths outbreak at 640000 (last 7 days)", x = "Date", y = "New deaths last 7 days")

x3_outbreak_list <-
  x3 %>% filter(outbreak_no != 0) %>%
  group_by(outbreak_no) %>%
  summarise (Start_date = min(date_key), End_date = max(date_key))