main_data <- cbind(filter_data,as.Date(filter_data$date,"%m/%d/%Y"))
colnames(main_data) <- c("iso_code","continent","location","date","new_cases","new_deaths","date_key")

#Them cot thang va dinh dang number
main_data["months"] = as.numeric(format(main_data$date_key, format = "%m"))
main_data["years"] = as.numeric(format(main_data$date_key, format ="%Y" ))
#Them cot thang va dinh dang number
main_data["months"] = as.numeric(format(main_data$date_key, format = "%m"))
main_data["years"] = as.numeric(format(main_data$date_key, format ="%Y" ))
#Loc du lieu theo dieu kien: quoc gia, thang thuc hien
ThangTH <-c(11,12)
Years <- c(unique(main_data$years))
QGia <- c(unique(main_data$location))

CasePerMonth <- main_data %>% filter(location==QGia[1] & months %in% ThangTH & years ==Years[1] )


#Thay the bao cao khong thuong xuyen bang gia tri trung binh cua bao cao 7 ngay gan nhat
CasePerMonth$new_deaths=floor(Reduce(function(x,y)if(is.na(y))c(x,mean(tail(x,2))) else c(x,y),CasePerMonth$new_deaths))
CasePerMonth$new_cases=floor(Reduce(function(x,y)if(is.na(y))c(x,mean(tail(x,2))) else c(x,y),CasePerMonth$new_cases))
CasePerMonth$date_key<-as.POSIXct(CasePerMonth$date_key, format="%Y-%m-%d")


#Ve bieu do
ggplot() +
  geom_line(mapping = aes(x = CasePerMonth$date_key, y = CasePerMonth$new_cases), color = "blue") +
  geom_line(mapping = aes(x = CasePerMonth$date_key, y = CasePerMonth$new_deaths/0.1), color = "red") +
  scale_y_continuous(name = "Ca nhiem", sec.axis = sec_axis(~.*0.1, name = "Ca tu vong")) +
  scale_x_datetime(date_breaks = "7 days", name = "Thoi gian", date_labels = "%m-%d-%Y") +
  ggtitle(QGia[3]) +
  theme(axis.title.y = element_text(color = "blue"),axis.title.y.right = element_text(color = "red")) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, color = "orange"))
