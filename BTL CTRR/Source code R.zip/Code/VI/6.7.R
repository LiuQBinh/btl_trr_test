main_data <- cbind(filter_data,as.Date(filter_data$date,"%m/%d/%Y"))
colnames(main_data) <- c("iso_code","continent","location","date","new_cases","new_deaths","date_key")

#Them cot thang va dinh dang number
main_data["months"] = as.numeric(format(main_data$date_key, format = "%m"))
main_data["years"] = as.numeric(format(main_data$date_key, format ="%Y" ))
#Loc du lieu theo dieu kien: quoc gia, thang thuc hien
ThangTH <-c(1,8,4,5)
Years <- c(unique(main_data$years))
QGia <- c(unique(main_data$location))
CasePerMonth <- main_data %>% filter(months==ThangTH[1] & location%in% QGia & years==Years[3] )

#Thay the bao cao khong thuong xuyen bang gia tri trung binh cua bao cao 7 ngay gan nhat
CasePerMonth$new_cases=floor(Reduce(function(x,y)if(is.na(y))c(x,mean(tail(x,2))) else c(x,y),CasePerMonth$new_cases))

#Ve bieu do tich luy
ggplot(data = CasePerMonth, aes(x=CasePerMonth$new_cases)) + geom_density(fill= "Orange") +
  scale_y_continuous(name = "Tich luy") +
  scale_x_continuous(breaks = round(seq(min(CasePerMonth$new_cases), max(CasePerMonth$new_cases), by = 200),200), name = "Thoi gian") +
  theme(axis.text.x = element_text(angle = 0, hjust = 1, color = "red")) +
  theme(axis.title.y = element_text(color = "blue"))+
  ggtitle("Bieu do tich luy-01/2022")

