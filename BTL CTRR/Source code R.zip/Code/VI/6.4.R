main_data <- cbind(filter_data,as.Date(filter_data$date,"%m/%d/%Y"))
colnames(main_data) <- c("iso_code","continent","location","date","new_cases","new_deaths","date_key")

#Them cot thang va dinh dang number
main_data["months"] = as.numeric(format(main_data$date_key, format = "%m"))
main_data["years"] = as.numeric(format(main_data$date_key, format ="%Y" ))
#Loc du lieu theo dieu kien: quoc gia, thang thuc hien
ThangTH <-c(11,12)
Years <- c(unique(main_data$years))
CasePerMonth <- main_data %>% filter(months %in% ThangTH & years ==Years[2] )
CasePerMonth$date_key<-as.POSIXct(CasePerMonth$date_key, format="%Y-%m-%d")

#Thay the bao cao khong thuong xuyen bang gia tri trung binh cua bao cao 7 ngay gan nhat
CasePerMonth$new_cases=floor(Reduce(function(x,y)if(is.na(y))c(x,mean(tail(x,2))) else c(x,y),CasePerMonth$new_cases))

#Ve bieu do ca tu vong
ggplot(data = CasePerMonth, aes(x=date_key, y=new_cases, group = location, colour = location)) +
  geom_line() +
  scale_x_datetime("Thoi gian", date_breaks = "7 days", date_labels = "%m-%d-%Y") +
  scale_y_continuous("Ca nhiem")+
  theme(axis.text.x = element_text(angle = 90, hjust = 1, color = "black"))