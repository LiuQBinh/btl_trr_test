library("readr")
library("xlsx")
library("dplyr")
library("stringr")
library("ggplot2")
library("RcppRoll")

raw_data <- read_csv ("D:\\ctrr\\owid-covid-data.csv")

main_data <- cbind(raw_data,as.Date(raw_data$date,"%m/%d/%Y"))
colnames(main_data) <- c("iso_code","continent","location","date","new_cases","new_deaths","date_key")
main_data <- main_data[order(main_data$iso_code,main_data$date_key,decreasing = FALSE),]

filter_data <- main_data %>% filter(location == c("Kenya", "Lesotho", "Morocco"))

ken <- main_data%>%
  filter(location == 'Kenya')
lso <- main_data%>%
  filter(location == 'Lesotho')
mar <- main_data%>%
  filter(location == 'Morocco')
# ************************************ Nhom cau ix *********************************************

--ix1

ggplot () + 
  geom_line(data = ken , aes(x = `date_key`, y = 100*cumsum(dplyr::coalesce(`new_cases`,0))/sum(dplyr::coalesce(`new_cases`,0))), color = "red") +
  geom_line(data = ken , aes(x = `date_key`, y = 100*cumsum(dplyr::coalesce(`new_deaths`,0))/sum(dplyr::coalesce(`new_deaths`,0))), color = "blue") +
  xlab ("Dates") +
  ylab("Cumulative percentage")

ggplot () + 
  geom_line(data = lso , aes(x = `date_key`, y = 100*cumsum(dplyr::coalesce(`new_cases`,0))/sum(dplyr::coalesce(`new_cases`,0))), color = "red") +
  geom_line(data = lso , aes(x = `date_key`, y = 100*cumsum(dplyr::coalesce(`new_deaths`,0))/sum(dplyr::coalesce(`new_deaths`,0))), color = "blue") +
  xlab ("Dates") +
  ylab("Cumulative percentage")

ggplot () + 
  geom_line(data = mar , aes(x = `date_key`, y = 100*cumsum(dplyr::coalesce(`new_cases`,0))/sum(dplyr::coalesce(`new_cases`,0))), color = "red") +
  geom_line(data = mar , aes(x = `date_key`, y = 100*cumsum(dplyr::coalesce(`new_deaths`,0))/sum(dplyr::coalesce(`new_deaths`,0))), color = "blue") +
  xlab ("Dates") +
  ylab("Cumulative percentage")
#=====================================================================================================================================
-- ix2

ix2_ken_jan <- cor(x = ken %>% filter (months(ken$date_key,TRUE) == "Jan") %>% select(new_cases), 
                   y = ken %>% filter (months(ken$date_key,TRUE) == "Jan") %>% select(new_deaths),use = "complete.obs")
ix2_ken_apr <- cor(x = ken %>% filter (months(ken$date_key,TRUE) == "Apr") %>% select(new_cases), 
                   y = ken %>% filter (months(ken$date_key,TRUE) == "Apr") %>% select(new_deaths),use = "complete.obs")
ix2_ken_may <- cor(x = ken %>% filter (months(ken$date_key,TRUE) == "May") %>% select(new_cases), 
                   y = ken %>% filter (months(ken$date_key,TRUE) == "May") %>% select(new_deaths),use = "complete.obs")
ix2_ken_aug <- cor(x = ken %>% filter (months(ken$date_key,TRUE) == "Aug") %>% select(new_cases), 
                   y = ken %>% filter (months(ken$date_key,TRUE) == "Aug") %>% select(new_deaths),use = "complete.obs")

ggplot () + 
  geom_point(data = ken %>% filter(months(ken$date_key,TRUE) == "Jan") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Kenya new_cases and new_deaths correlation in January p = ",round(ix2_ken_jan, 4)) , x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ken %>% filter(months(ken$date_key,TRUE) == "Apr") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Kenya new_cases and new_deaths correlation in April p = ",round(ix2_ken_apr, 4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ken %>% filter(months(ken$date_key,TRUE) == "May") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Kenya new_cases and new_deaths correlation in May p = ",round(ix2_ken_may, 4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ken %>% filter(months(ken$date_key,TRUE) == "Aug") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Kenya new_cases and new_deaths correlation in August p = ",round(ix2_ken_aug, 4)), x = "New cases", y = "New deaths")

ix2_mar_jan <- cor(x = mar %>% filter (months(mar$date_key,TRUE) == "Jan") %>% select(new_cases), 
                   y = mar %>% filter (months(mar$date_key,TRUE) == "Jan") %>% select(new_deaths),use = "complete.obs")
ix2_mar_apr <- cor(x = mar %>% filter (months(mar$date_key,TRUE) == "Apr") %>% select(new_cases), 
                   y = mar %>% filter (months(mar$date_key,TRUE) == "Apr") %>% select(new_deaths),use = "complete.obs")
ix2_mar_may <- cor(x = mar %>% filter (months(mar$date_key,TRUE) == "May") %>% select(new_cases), 
                   y = mar %>% filter (months(mar$date_key,TRUE) == "May") %>% select(new_deaths),use = "complete.obs")
ix2_mar_aug <- cor(x = mar %>% filter (months(mar$date_key,TRUE) == "Aug") %>% select(new_cases), 
                   y = mar %>% filter (months(mar$date_key,TRUE) == "Aug") %>% select(new_deaths),use = "complete.obs")

ggplot () + 
  geom_point(data = mar %>% filter(months(mar$date_key,TRUE) == "Jan") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Morocco new_cases and new_deaths correlation in January p = ",round(ix2_mar_jan, 4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = mar %>% filter(months(mar$date_key,TRUE) == "Apr") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Morocco new_cases and new_deaths correlation in April p = ",round(ix2_mar_apr, 4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = mar %>% filter(months(mar$date_key,TRUE) == "May") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Morocco new_cases and new_deaths correlation in May p = ",round(ix2_mar_may, 4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = mar %>% filter(months(mar$date_key,TRUE) == "Aug") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Morocco new_cases and new_deaths correlation in August p = ",round(ix2_mar_aug, 4)), x = "New cases", y = "New deaths")

ix2_lso_jan <- cor(x = lso %>% filter (months(lso$date_key,TRUE) == "Jan") %>% select(new_cases), 
                   y = lso %>% filter (months(lso$date_key,TRUE) == "Jan") %>% select(new_deaths),use = "complete.obs")
ix2_lso_apr <- cor(x = lso %>% filter (months(lso$date_key,TRUE) == "Apr") %>% select(new_cases), 
                   y = lso %>% filter (months(lso$date_key,TRUE) == "Apr") %>% select(new_deaths),use = "complete.obs")
ix2_lso_may <- cor(x = lso %>% filter (months(lso$date_key,TRUE) == "May") %>% select(new_cases), 
                   y = lso %>% filter (months(lso$date_key,TRUE) == "May") %>% select(new_deaths),use = "complete.obs")
ix2_lso_aug <- cor(x = lso %>% filter (months(lso$date_key,TRUE) == "Aug") %>% select(new_cases), 
                   y = lso %>% filter (months(lso$date_key,TRUE) == "Aug") %>% select(new_deaths),use = "complete.obs")


ggplot () + 
  geom_point(data = lso %>% filter(months(lso$date_key,TRUE) == "Jan") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Lesotho new_cases and new_deaths correlation in January p = ",round(ix2_lso_jan, 4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = lso %>% filter(months(lso$date_key,TRUE) == "Apr") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Lesotho new_cases and new_deaths correlation in April p = ",round(ix2_lso_apr, 4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = lso %>% filter(months(lso$date_key,TRUE) == "May") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Lesotho new_cases and new_deaths correlation in May p = ",round(ix2_lso_may, 4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = lso %>% filter(months(lso$date_key,TRUE) == "Aug") , aes(x = `new_cases`, y = new_deaths), color = "red") +
  labs(title = paste("Lesotho new_cases and new_deaths correlation in August p = ",round(ix2_lso_aug, 4)), x = "New cases", y = "New deaths")
#======================================================================================================================
-- ix3
ix3_ken <- cbind(data.frame(cbind(roll_mean(ken$new_cases,7,fill = NA, align = "right"),roll_mean(ken$new_deaths,7,fill = NA, align = "right"))),months(ken$date_key,TRUE))
colnames(ix3_ken) <- c("avg_7_day_new_cases", "avg_7_day_new_deaths", "month")

ix3_ken_jan <- cor(ix3_ken %>% filter(ix3_ken$month == "Jan") %>% select(avg_7_day_new_cases),ix3_ken %>% filter(ix3_ken$month == "Jan") %>% select(avg_7_day_new_deaths), use = "complete.obs")
ix3_ken_apr <- cor(ix3_ken %>% filter(ix3_ken$month == "Apr") %>% select(avg_7_day_new_cases),ix3_ken %>% filter(ix3_ken$month == "Apr") %>% select(avg_7_day_new_deaths), use = "complete.obs")
ix3_ken_may <- cor(ix3_ken %>% filter(ix3_ken$month == "May") %>% select(avg_7_day_new_cases),ix3_ken %>% filter(ix3_ken$month == "May") %>% select(avg_7_day_new_deaths), use = "complete.obs")
ix3_ken_aug <- cor(ix3_ken %>% filter(ix3_ken$month == "Aug") %>% select(avg_7_day_new_cases),ix3_ken %>% filter(ix3_ken$month == "Aug") %>% select(avg_7_day_new_deaths), use = "complete.obs")

ggplot () + 
  geom_point(data = ix3_ken %>% filter(ix3_ken$month == "Jan") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Kenya new_cases and new_deaths correlation in January \n(average in last 7 days) p = ", round(ix3_ken_jan,4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ix3_ken %>% filter(ix3_ken$month == "Apr") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Kenya new_cases and new_deaths correlation in April \n(average in last 7 days) p = ", round(ix3_ken_apr,4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ix3_ken %>% filter(ix3_ken$month == "May") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Kenya new_cases and new_deaths correlation in May \n(average in last 7 days) p = ", round(ix3_ken_may,4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ix3_ken %>% filter(ix3_ken$month == "Aug") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Kenya new_cases and new_deaths correlation in August \n(average in last 7 days) p = ", round(ix3_ken_aug,4)), x = "New cases", y = "New deaths")

ix3_lso <- cbind(data.frame(cbind(roll_mean(lso$new_cases,7,fill = NA, align = "right"),roll_mean(lso$new_deaths,7,fill = NA, align = "right"))),months(lso$date_key,TRUE))
colnames(ix3_lso) <- c("avg_7_day_new_cases", "avg_7_day_new_deaths", "month")

ix3_lso_jan <- cor(ix3_lso %>% filter(ix3_lso$month == "Jan") %>% select(avg_7_day_new_cases),ix3_lso %>% filter(ix3_lso$month == "Jan") %>% select(avg_7_day_new_deaths), use = "complete.obs")
ix3_lso_apr <- cor(ix3_lso %>% filter(ix3_lso$month == "Apr") %>% select(avg_7_day_new_cases),ix3_lso %>% filter(ix3_lso$month == "Apr") %>% select(avg_7_day_new_deaths), use = "complete.obs")
ix3_lso_may <- cor(ix3_lso %>% filter(ix3_lso$month == "May") %>% select(avg_7_day_new_cases),ix3_lso %>% filter(ix3_lso$month == "May") %>% select(avg_7_day_new_deaths), use = "complete.obs")
ix3_lso_aug <- cor(ix3_lso %>% filter(ix3_lso$month == "Aug") %>% select(avg_7_day_new_cases),ix3_lso %>% filter(ix3_lso$month == "Aug") %>% select(avg_7_day_new_deaths), use = "complete.obs")

ggplot () + 
  geom_point(data = ix3_lso %>% filter(ix3_lso$month == "Jan") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Lesotho new_cases and new_deaths correlation in January \n(average in last 7 days) p = ", round(ix3_lso_jan,4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ix3_lso %>% filter(ix3_lso$month == "Apr") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Lesotho new_cases and new_deaths correlation in April \n(average in last 7 days) p = ", round(ix3_lso_apr,4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ix3_lso %>% filter(ix3_lso$month == "May") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Lesotho new_cases and new_deaths correlation in May \n(average in last 7 days) p = ", round(ix3_lso_may,4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ix3_lso %>% filter(ix3_lso$month == "Aug") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Lesotho new_cases and new_deaths correlation in August \n(average in last 7 days) p = ", round(ix3_lso_aug,4)), x = "New cases", y = "New deaths")

ix3_mar <- cbind(data.frame(cbind(roll_mean(mar$new_cases,7,fill = NA, align = "right"),roll_mean(mar$new_deaths,7,fill = NA, align = "right"))),months(mar$date_key,TRUE))
colnames(ix3_mar) <- c("avg_7_day_new_cases", "avg_7_day_new_deaths", "month")

ix3_mar_jan <- cor(ix3_mar %>% filter(ix3_mar$month == "Jan") %>% select(avg_7_day_new_cases),ix3_mar %>% filter(ix3_mar$month == "Jan") %>% select(avg_7_day_new_deaths), use = "complete.obs")
ix3_mar_apr <- cor(ix3_mar %>% filter(ix3_mar$month == "Apr") %>% select(avg_7_day_new_cases),ix3_mar %>% filter(ix3_mar$month == "Apr") %>% select(avg_7_day_new_deaths), use = "complete.obs")
ix3_mar_may <- cor(ix3_mar %>% filter(ix3_mar$month == "May") %>% select(avg_7_day_new_cases),ix3_mar %>% filter(ix3_mar$month == "May") %>% select(avg_7_day_new_deaths), use = "complete.obs")
ix3_mar_aug <- cor(ix3_mar %>% filter(ix3_mar$month == "Aug") %>% select(avg_7_day_new_cases),ix3_mar %>% filter(ix3_mar$month == "Aug") %>% select(avg_7_day_new_deaths), use = "complete.obs")

ggplot () + 
  geom_point(data = ix3_mar %>% filter(ix3_mar$month == "Jan") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Morocco new_cases and new_deaths correlation in January \n(average in last 7 days) p = ", round(ix3_mar_jan,4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ix3_mar %>% filter(ix3_mar$month == "Apr") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Morocco new_cases and new_deaths correlation in April \n(average in last 7 days) p = ", round(ix3_mar_apr,4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ix3_mar %>% filter(ix3_mar$month == "May") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Morocco new_cases and new_deaths correlation in May \n(average in last 7 days) p = ", round(ix3_mar_may,4)), x = "New cases", y = "New deaths")
ggplot () + 
  geom_point(data = ix3_mar %>% filter(ix3_mar$month == "Aug") , aes(x = `avg_7_day_new_cases`, y = avg_7_day_new_deaths), color = "red") +
  labs(title = paste("Morocco new_cases and new_deaths correlation in August \n(average in last 7 days) p = ", round(ix3_mar_aug,4)), x = "New cases", y = "New deaths")